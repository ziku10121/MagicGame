﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Scene_switch : MonoBehaviour {

	// Use this for initialization
	public void UI1 () {
		SceneManager.LoadScene ("UI_first");
	}
}
	
