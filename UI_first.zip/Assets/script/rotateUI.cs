﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class rotateUI : MonoBehaviour {
	float rotationleft=360;
	float rotationspeed=100;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		float rotation = rotationspeed * Time.deltaTime;

		if (rotationleft > rotation) {
			rotationleft -= rotation;
		}
		else{
			rotation = rotationleft;
			rotationleft = 3;

		}
		transform.Rotate(0,0,rotation);
	}
}